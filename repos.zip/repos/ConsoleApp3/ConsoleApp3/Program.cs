﻿using System;
class Person
{
    private string Name;
    private DateTime DOB;
    private string Address;
    private string Maritalstatus;
    private int age;

    public  Person(string name, DateTime dob, string address, string maritalstatus)
    {
        this.Name = name;
        this.DOB = dob;
        this.Address = address;
        this.Maritalstatus = maritalstatus;

    }
    public int Age
    {
       
        get 
        {
            return (DateTime.Now.Year) - (DOB.Year); ;
        }
       

    }
    private bool CanMarry()
    {
        if(Age > 18 && Maritalstatus=="single")
        {
            return true ;
        }
        else
        {
            return false;
        }
    }
    public  string  PrintDetails()
    {
        
        if (CanMarry()==true)
        {
            return $"{Name}  lives at {Address},born on {DOB} ,{Maritalstatus},{Age} years old and can marry ";
        }
        else
        {
            return $"{Name}  lives at {Address},born on {DOB} ,{Maritalstatus},{Age} years old and can't marry ";
        }
    }
    public static void Main(string[] args)
    {
        Person p = new Person("sreedhar",DateTime.Parse("2000/02/01"),"43,nyc","single");
        Console.WriteLine(p.PrintDetails());

    }
}
        