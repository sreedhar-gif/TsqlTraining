﻿using System;

class maths
{
    public int getsum(int n)
    {
        int sum = 0;
        while (n != 0)
        {
            sum = sum + n % 10;
        }
        return sum;
    }
    public static  int Main()
    {
        int n=1478;
        Console.WriteLine(getsum(n));

    }
}