﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FirstConsoleApp
{
    internal class Stu
    {
        public int lmsid { get; set; } //auto imp property
        public string? email { get; set; }

        override public string ToString()
        {
            return $"LMSId={lmsid}, email={email}";
        }
    }

    class Trainee : Stu
    {
        public string? Competency { get; set; }
        public List<string>? skills { get; set; }

        public override string ToString()
        {
            return $"BasicDetails={base.ToString()}, competencyName={Competency},Skills={string.Join(",", skills)}";
        }
    }




}
