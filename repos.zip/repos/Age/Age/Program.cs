﻿using System;
namespace age
{
    class Updatedage
    {

        public Updatedage()
        {
            Age += 10;
            Console.WriteLine(Age);
        }

        public int Age { get; private set; }

        public static void Main()
        {
            Updatedage age = new Updatedage();
            age.Age = 20;
        }

    }
}
