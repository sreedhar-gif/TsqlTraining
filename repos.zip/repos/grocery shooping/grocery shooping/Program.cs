﻿using System;
class Customer
{
    public int Id { get; set; }
    public string? Name { get; set; }
    public double TotalPurchases { get; set; }

    public Customer(int id,string? name,double totalpurchases)
    {
        Id = id;
        Name = name;
        TotalPurchases = totalpurchases;
    }
    public string Getcontactinfo() 
    {
        return "contactinfo";
    }
    public string GetTransactionHistory()
    {
        return "History";
    }
     public void Print()
    {
        Console.WriteLine(
    }
}
class program
{
    public static void Main()
    {
        Customer cust1 = new Customer(32451, "John", 4565.21);
        cust1.TotalPurchases += 458.32;
    }
}
