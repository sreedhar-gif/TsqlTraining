﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace subsetarray
{
    class subset
    { 
            static void Main(string[] args)
            {
               var test= Foo<int>(new int[] { 10, 20, 30,41 });
               
                foreach(var t  in test)
                {
                    var temp = string.Join<int>(",", t);
                    temp = "{" + temp + "}";
                    Console.WriteLine(temp);
                }
                Console.ReadLine();
            }

        static List<List<T>> Foo<T>(T[] set)
        {
            // Init list
            List<List<T>> subsets = new List<List<T>>();

            subsets.Add(new List<T>()); // add the empty set

            // Loop over individual elements
            for (int i = 1; i < set.Length; i++)
            {
                subsets.Add(new List<T>() { set[i - 1] });

                List<List<T>> newSubsets = new List<List<T>>();

                // Loop over existing subsets
                for (int j = 0; j < subsets.Count; j++)
                {
                    var newSubset = new List<T>();
                    foreach (var temp in subsets[j])
                        newSubset.Add(temp);
                   // if(newSubset.Contains!=subsets)
                    newSubset.Add(set[i]);
                    newSubsets.Add(newSubset);
                }

                subsets.AddRange(newSubsets);
            }

            // Add in the last element
            subsets.Add(new List<T>() { set[set.Length - 1] });
            //subsets.iSort();
 

            return subsets;
        }
    }
}

