﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Globalization;

namespace FirstConsoleApp
{
    public class Emp
    {
        public int empid;
        public string name;
        protected string department;
        private int salary;
        private double _salary;
        public DateTime DOJ;

        

        public TimeSpan Tenure()
        {

            DateTime t1 = DateTime.Now;
            return t1.Subtract(DOJ);
            
        }

        //properties
        //getter - to read data
        //setter - to write data
       
        public string Dept
        {
            get
            {
                return department;
            }
            set { department = value; }
        }

        public int Sal
        {
            get
            {
                if (Sal >= 60000)
                    return 3;
                else
                    return 2;
            }
            set { salary = value;
                _salary = salary * 79.08;

            }
        }    
        override public string ToString()
        {
            return $"Id={this.empid},Name={this.name},Department={this.department},Salary(in Rs)={this._salary}, tenure={ Tenure()} ";
        }
    }
}
