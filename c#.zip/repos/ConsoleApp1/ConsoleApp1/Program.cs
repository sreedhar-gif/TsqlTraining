﻿// See https://aka.ms/new-console-template for more information
using FirstConsoleApp;
//fruits[3] = 93475;

//Emp e = new Emp();
//e.empid = 5050;
//e.name = "Mary";

var emps = new Emp[] {
    new Emp { empid=22554,name="Darshith",Sal=600000, Dept="Azure MCS"}, //object intializer
    new Emp { empid=22559,name="Sreedhar",Sal=600000, Dept="D365"},
    new Emp { empid=22563,name="Akshay",Sal=600000, Dept="D365"}
};
for (int i = 0; i < emps.Length; i++)
    Console.WriteLine(emps[i].ToString());

//foreach (var e in emps) emp
//Console.WriteLine(e.ToString());
List<Emp> TTS = new List<Emp>();
TTS.Add(new Emp { empid = 1, name = "Sanjana", Dept = "Microsoft", Sal = 76000,DOJ=new DateTime(2020,03,22)});
TTS.Add(new Emp { empid = 12, name = "Rajan", Dept = "D365", Sal = 1000, DOJ = new DateTime(2022,07,01) });
TTS.Add(new Emp { empid = 13, name = "Varun", Dept = "Open Source", Sal = 6000, DOJ = new DateTime(2021,09,22) });


foreach (Emp e in TTS)
    Console.WriteLine(e.ToString());

//Console.WriteLine(TTS.Contains(e));


//foreach (var e in TTS)
//    Console.WriteLine(e.ToString());

//Stu s1 = new Stu { lmsid = 12, email = "rohith.n" };

List<Trainee> trainees = new List<Trainee>();
trainees.Add(new Trainee
{
    lmsid = 12,
    email = "anish.a",
    Competency = "D&A",
    skills = new List<string> { "SQL", "TSQL", "Excel", "PowerBI" }
});

trainees.Add(new Trainee
{
    lmsid = 12,
    email = "anish.a",
    Competency = "D365",
    skills = new List<string> { "SQL", "TSQL", "X++", "D365" }
});

//foreach (Trainee trainee in trainees)
//    Console.WriteLine(trainee.ToString());






