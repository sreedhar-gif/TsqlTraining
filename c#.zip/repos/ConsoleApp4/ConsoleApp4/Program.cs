﻿using System;
 class Human
{
    private string Fname;
    private string Lname;

    public string fname
    {
        get{return Fname;}
        set{Fname = value;}
    }
    public string lname
    {
        get{return Lname;}
        set{Lname = value;}
    }
}
class Student : Human
{
    private int marks;
    public  Student(int marks)
    {
        this.marks = marks;
    }
}