﻿using System;

 class Circle
    {
        private double Radius;
        public void  SetRadius(double Radius)
        {
            this.Radius= Radius;
        }
        public double  GetRadius()
        {
            return Radius;
        }
        public double CalcDiameter()
        {
            double diameter = 0;
            diameter=Radius / 2;
            return diameter;
        }
        public double GetArea()
        {
            double area = 0;
            area = 3.14 * Radius * Radius;
            return area;
        }
    public static void Main() 
    {
    Circle circle = new Circle();
        circle.CalcDiameter();
        Console.WriteLine("Enter Radius");
        
        double Radius=double.Parse(Console.ReadLine());
        circle.SetRadius(Radius);
    }

}
